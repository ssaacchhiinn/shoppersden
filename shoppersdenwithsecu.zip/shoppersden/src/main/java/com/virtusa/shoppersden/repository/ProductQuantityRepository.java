package com.virtusa.shoppersden.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.shoppersden.models.ProductQuantity;

public interface ProductQuantityRepository extends JpaRepository<ProductQuantity,Integer> {

}
