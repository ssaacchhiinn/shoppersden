package com.virtusa.shoppersden.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.virtusa.shoppersden.models.Category;
import com.virtusa.shoppersden.services.CategoryService;

@Controller()
public class CategoryController {

	@Autowired
	private CategoryService categoryService;
	
	@GetMapping("/category")
	public String category(Model model)
	{
		model.addAttribute("getcategorities", categoryService.getAllCategories());
		return "admin/category";
	}
 
	@PostMapping("/addcategory")
	public String addCategory(@ModelAttribute Category category,Model model) {
		model.addAttribute("categorymessage",categoryService.addCategory(category));
		return "redirect:/category";
	} 
 
	@RequestMapping("/deletecategory/{categoryId}")
	public String deleteCategory(@PathVariable int categoryId) {
		categoryService.deleteCategory(categoryId);
		return "redirect:/category";
	}
	
}
