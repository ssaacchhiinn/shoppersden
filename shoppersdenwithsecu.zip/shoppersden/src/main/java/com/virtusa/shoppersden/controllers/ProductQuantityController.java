package com.virtusa.shoppersden.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import com.virtusa.shoppersden.models.ProductQuantity;
import com.virtusa.shoppersden.services.ProductQuantityService;

@Controller
@SessionAttributes("phoneNumber")
public class ProductQuantityController {

	@Autowired
	private ProductQuantityService productQtyService;

	@GetMapping("/getproductquantities")
	public List<ProductQuantity> getAllProductQuantities() {
		return productQtyService.getAllProductQuantities();
	}

	@PostMapping("/addproductquantity")
	public @ResponseBody ProductQuantity addProductQuantity(@ModelAttribute("phoneNumber") long phoneNumber,@RequestBody int productId) {
		return productQtyService.addProductQuantity(phoneNumber,productId);
	}

	@PostMapping("/deleteproductquantity")
	public void deleteProductQuantity(int productQtyId) {
		productQtyService.deleteProductQuantity(productQtyId);
	}
	
}
