package com.virtusa.shoppersden.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.virtusa.shoppersden.models.User;
import com.virtusa.shoppersden.services.UserService;
@Controller
@SessionAttributes("phoneNumber")
public class UserProfileController {

	@Autowired
	private UserService userService;
	
	@GetMapping("/profile")
	public String profile(@ModelAttribute("phoneNumber") long phoneNumber,Model model)
	{ 
		model.addAttribute("userprofile", userService.findUserById(phoneNumber));
		return "profile";
	}
	
	@PostMapping("/updateuserprofile")
	public String updateUserProfile(@ModelAttribute User user,@ModelAttribute("phoneNumber") long phoneNumber,Model model) {
		model.addAttribute("profilemsg", userService.updateUserProfile(user)); 
		model.addAttribute("userprofile", userService.findUserById(phoneNumber));
		return "profile";
	}
	
	@PostMapping("/updateuserpassword")
	public String updateUserPassword(@ModelAttribute User user,@ModelAttribute("phoneNumber") long phoneNumber,Model model) {
		model.addAttribute("passwordmsg",userService.updateUserPassword(user));
		model.addAttribute("userprofile", userService.findUserById(phoneNumber));
		return "profile";
	}
	
}
