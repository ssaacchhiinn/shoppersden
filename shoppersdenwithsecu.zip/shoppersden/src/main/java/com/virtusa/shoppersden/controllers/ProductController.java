package com.virtusa.shoppersden.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import com.virtusa.shoppersden.models.Product;
import com.virtusa.shoppersden.services.CategoryService;
import com.virtusa.shoppersden.services.FileUploadService;
import com.virtusa.shoppersden.services.ProductService;

@Controller
public class ProductController {

	@Autowired
	private ProductService productService;
	@Autowired
	private CategoryService categoryService;
	@Autowired
	private FileUploadService fileUploadService;
	
	
	@GetMapping("/product")
	public String getAllProducts(Model model) {
		model.addAttribute("getproducts", productService.getAllProducts());
		model.addAttribute("getcategorities", categoryService.getAllCategories());
		return "admin/product";
	}

	@PostMapping("/addproduct")
	public String addProduct(@ModelAttribute Product product, @RequestParam(name = "category") int categoryId,@RequestParam MultipartFile imageURL) {
		fileUploadService.uploadFile(imageURL);
		product.setImgURL("/images/products/"+imageURL.getOriginalFilename());
		productService.addProduct(product, categoryId);
		return "redirect:/product";
	}

	@PostMapping("/updateproduct/{categoryId}")
	public Product updateProduct(@RequestBody Product product, @PathVariable int categoryId) {
		return productService.updateProduct(product, categoryId);
	}

	@RequestMapping("/deleteproduct/{productId}")
	public String deleteProduct(@PathVariable int productId) {
		productService.deleteProduct(productId);
		return "redirect:/product";
	}
	
	@GetMapping("/getproductbycategory/{categoryId}")
	public String getProductByCategory(@PathVariable int categoryId,Model model) {
		model.addAttribute("allcategory",categoryService.getAllCategories());
		model.addAttribute("getproducts",productService.getFilterProduct(categoryId));
		return "index";
	}
	
	@GetMapping("/getproductbycategoryhome/{categoryId}")
	public String getProductByCategoryHome(@PathVariable int categoryId,Model model) {
		model.addAttribute("allcategory",categoryService.getAllCategories());
		model.addAttribute("getproducts",productService.getFilterProduct(categoryId));
		return "customer/home";
	} 
	  
}
