package com.virtusa.shoppersden.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.virtusa.shoppersden.models.Payment;
import com.virtusa.shoppersden.services.PaymentService;

@Controller
public class PaymentController {

	@Autowired
	private PaymentService paymentService;

	@GetMapping("/payment")
	public String getAllPayments(Model model) {
		model.addAttribute("getpayments",paymentService.getAllPayments());
		 return "admin/transaction";
	}

	@PostMapping("/addpayment")
	public Payment addPayment(@RequestBody Payment payment, int orderId) {
		return paymentService.addPayment(payment, orderId);
	}

	@PostMapping("/updatepayment")
	public Payment updatePayment(@RequestBody Payment payment, int orderId) {
		return paymentService.updatePayment(payment, orderId);
	}
	
	@PostMapping("/deletepayment")
	public void deletePayment( int transactionId) {
		 paymentService.deletePayment(transactionId);
	}
	
}
