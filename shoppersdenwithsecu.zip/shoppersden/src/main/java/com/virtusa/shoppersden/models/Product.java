package com.virtusa.shoppersden.models;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Product")
public class Product  {

	@Id
	@GenericGenerator(name="productId" , strategy="increment")
	@GeneratedValue(generator="productId")
	@Column(name = "Product_Id")
	private int productId;
	
	@Column(name = "Product_Name", length = 50, nullable = false)
	private String productName;
	
	@Column(name = "Price")
	private long price;
	
	@Column(name = "Stock")
	private int stock;
	
	@Column(name = "Image_URL", length = 50)
	private String imgURL;
	
	@Column(name = "Specification", length=200)
	private String specification;

	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
	@JoinColumn(name = "Category_Id", nullable = false)
	private Category category;

		
	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public long getPrice() {
		return price;
	}

	public void setPrice(long price) {
		this.price = price;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public String getImgURL() {
		return imgURL;
	}

	public void setImgURL(String imgURL) {
		this.imgURL = imgURL;
	}

	public String getSpecification() {
		return specification;
	}

	public void setSpecification(String specification) {
		this.specification = specification;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

}
