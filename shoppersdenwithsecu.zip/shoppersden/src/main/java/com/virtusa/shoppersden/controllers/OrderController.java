package com.virtusa.shoppersden.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.virtusa.shoppersden.models.Order;
import com.virtusa.shoppersden.services.OrderService;

@Controller
public class OrderController {

	@Autowired
	private OrderService orderService;

	@GetMapping("/order")
	public String getAllOrders(Model model) {
		model.addAttribute("getorders",  orderService.getAllOrders());
		 return "admin/order";
	}

	@PostMapping("/addorder")
	public Order addOrder(@RequestBody Order order) {
		return orderService.addOrder(order);
	}

	@PostMapping("/updateorder")
	public Order updateOrder(@RequestBody Order order) {
		return orderService.updateOrder(order);
	}

	@PostMapping("/deleteorder")
	public void deleteOrder(int orderId) {
		orderService.deleteOrder(orderId);
	}

}
