function setprofilevalues()
{
	$('input[name="userName"]').val($('#userprofileusername').text());
	$('input[name="email"]').val($('#userprofileemail').text());
	$('input[name="phoneNumber"]').val($('#userprofilephonenumber').text());
}

$(document).ready(function(){
	$('#userprofilehidden').hide();
	setprofilevalues();
	var bname=$('#name').val();
	$('#updateprofileform').submit(function(){
		var aname=$('#name').val();
		if(bname!=aname)
		{
			return true;
		}else
		{
			$('#updateerr').css('display','block');
			return false;
		}
	});

	$('#cnfpass').keyup(function(){
		var npass=$('#npass').val();
		var cnfpass=$(this).val();
		if(npass!=cnfpass)
		{
			$('#errmsg').show();
		}
		else{
			$('#errmsg').hide();
		}
	});
	$('#passwordform').submit(function(){
		var npass=$('#npass').val();
		var cnfpass=$('#cnfpass').val();
		if(npass!=cnfpass)
		{
			return false;
		}
		else{return true;}
	});
	$('#chgpass').click(function() {
		$('#chgpassform').toggle("slow");
		if ($(this).val() == "Change Password") {
			$(this).val("Close");
			$('#y11').addClass("col-sm-6");
			$("#y11").removeClass("col-sm-12");
		}
		else {
			$(this).val("Change Password");
			$('#y11').addClass("col-sm-12");
		}
	});

	$('#ename').click(function(){
		if($('#name').prop("disabled") ==true)
		{
			$('#name').prop("disabled", false);
			$('#name').css('border','#28de28 2px solid');
		}
		else
		{
			$('#name').prop("disabled", true);
			$('#name').css('border','rgb(206, 212, 218) 1px solid');
		}

	});
});