$('.table').DataTable({
		lengthMenu:[5,10,25,50,100]
	});