$('.table tbody').on('click','.btn-warning',function(){
	var currow=$(this).closest('tr');
	var questionId=currow.find('td:eq(0)').text();
	var question=currow.find('td:eq(1)').text();
	$('#question').val(question);
	$('#questionId').attr('name', 'questionId').val(questionId);
	$('#title-addquestion').html("Update Question");
	$('#addquestion').html('Update');
});
$('#openaddquestion').click(function(){
	$('#question').val("");
	$('#questionId').removeAttr("name");
	$('#title-addquestion').html("Add New Question");
	$('#addquestion').html('Add Question');
});
$('.table').DataTable({
	lengthMenu:[5,10,25,50,100]
});