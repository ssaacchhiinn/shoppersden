package com.virtusa.shoppersden.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.virtusa.shoppersden.models.User;
import com.virtusa.shoppersden.models.UserRole;
import com.virtusa.shoppersden.models.SecurityQuestion;
import com.virtusa.shoppersden.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private SecurityQuestionService securityQuestionService;
	@Autowired
	private UserRoleService userRoleService;

	public List<User> getAllUsers() {
		return userRepository.findAll();
	}
	
	public User findUserById(long phoneNumber)
	{
		return userRepository.findById(phoneNumber).orElse(null);
	}

	public User addUser(User user,int questionId)
	{
		 SecurityQuestion question =securityQuestionService.findQuestionById(questionId);
		 user.setSecurityQuestion(question);
		 UserRole userRole=userRoleService.getUserRoleById(2);
		 user.setUserRole(userRole);
		 return userRepository.save(user);
	}

	public User updateUserProfile(User user)
	{
		User oldUser=findUserById(user.getPhoneNumber());
		oldUser.setUserName(user.getUserName());
		return userRepository.save(oldUser);
	}
	
	public User updateUserPassword(User user)
	{
		User oldUser=findUserById(user.getPhoneNumber());
		oldUser.setPassword(user.getPassword());
		return userRepository.save(oldUser);
	}
	
	public User updateUserRole(User user)
	{
		User oldUser=findUserById(user.getPhoneNumber());
		oldUser.setUserRole(user.getUserRole());
		oldUser.setEnabled(user.getEnabled());
		return userRepository.save(oldUser);
	}
	
	public boolean deleteUser(long userId)
	{
		boolean status = false;
		userRepository.deleteById(userId);
		status = true;
		return status;
	}

	public User getUser(long userid) { 
		  return userRepository.findById(userid).orElse(null); 
	}
	 
	public User updateUser(User user, int questionId)
	{
		SecurityQuestion question = securityQuestionService.findQuestionById(questionId);
		user.setSecurityQuestion(question);
		return userRepository.save(user);
	}

	public boolean authenticateUser(User user)
	{
		String pass=user.getPassword();
		Long userid=user.getPhoneNumber();
		User user1=userRepository.findById(userid).orElse(null);
		if(user1.getPassword().equals(pass))
		   return true;
		else
			return false;
	}
	
	public SecurityQuestion getuserSequerityquestion(User user)
	{
		Long userid=user.getPhoneNumber();
		User user1=userRepository.findById(userid).orElse(null);
		SecurityQuestion question=user1.getSecurityQuestion();
		return question;
	}
	
	public boolean sequerityAnswerCheck(User user)
	{
		long userid=user.getPhoneNumber();
		String formanswer=user.getAnswer();
		User user1=userRepository.findById(userid).orElse(null);
		String userAnswer=user1.getAnswer();
		if(formanswer.equals(userAnswer))
			return true;
		else
			return false;
	}
	
}
