package com.virtusa.shoppersden.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Security_Question")
public class SecurityQuestion {

	@Id
	@GenericGenerator(name="questionId" , strategy="increment")
	@GeneratedValue(generator="questionId")
	@Column(name = "Question_Id", updatable = false)
	private int questionId;

	@Column(name = "Question", unique = true, nullable = false, length = 100)
	private String question;

	public int getQuestionId() {
		return questionId;
	}

	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

}
