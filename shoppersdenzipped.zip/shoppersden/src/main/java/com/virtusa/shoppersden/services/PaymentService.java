package com.virtusa.shoppersden.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.shoppersden.models.Order;
import com.virtusa.shoppersden.models.Payment;
import com.virtusa.shoppersden.repository.PaymentRepository;

@Service
public class PaymentService {

	@Autowired
	private PaymentRepository paymentRepository;
	@Autowired
	private OrderService orderService;

	public List<Payment> getAllPayments() {
		return paymentRepository.findAll();
	}

	public Payment getPaymentByTransId(int transactionId) {
		return paymentRepository.findById(transactionId).orElse(null);
	}

	public Payment addPayment(Payment payment, int orderId) {
		Order order = orderService.getOrderByOrderId(orderId);
		payment.setOrder(order);
		return paymentRepository.save(payment);
	}

	public Payment updatePayment(Payment payment, int orderId) {
		Order order = orderService.getOrderByOrderId(orderId);
		payment.setOrder(order);
		return paymentRepository.save(payment);
	}

	public boolean deletePayment(int transactionId) {
		boolean status = false;
		paymentRepository.deleteById(transactionId);
		status = true;
		return status;
	}
	
}
