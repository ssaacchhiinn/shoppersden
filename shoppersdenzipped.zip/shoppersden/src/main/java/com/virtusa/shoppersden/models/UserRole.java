package com.virtusa.shoppersden.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "User_Role")
public class UserRole {

	@Id
	@GenericGenerator(name="userRoleId" , strategy="increment")
	@GeneratedValue(generator="userRoleId")
	@Column(name = "Role_Id")
	private int userRoleId;
	
	@Column(name = "ROLE", length = 15)
	private String role;

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public int getUserRoleId() {
		return userRoleId;
	}

	public void setUserRoleId(int userRoleId) {
		this.userRoleId = userRoleId;
	}

}