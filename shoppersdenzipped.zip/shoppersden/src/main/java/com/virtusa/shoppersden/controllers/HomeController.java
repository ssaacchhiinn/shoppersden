package com.virtusa.shoppersden.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import com.virtusa.shoppersden.services.CategoryService;
import com.virtusa.shoppersden.services.ProductService;
import com.virtusa.shoppersden.services.SecurityQuestionService;

@Controller()
public class HomeController {

	@Autowired
	private ProductService productService;
	@Autowired
    private CategoryService categoryService;
	@Autowired 
	private SecurityQuestionService securityQuestionService;
	
	@GetMapping("/")
	public String home(Model model)
	{
		model.addAttribute("allcategory",categoryService.getAllCategories());
		model.addAttribute("getproducts", productService.getAllProducts());
		return "index";
	}

	@GetMapping("/admin")
	public String adminHome()
	{
		return "admin/home";
	}
	
	@GetMapping("/login")
	public String userLogin()
	{
		return "login";
	}
	
	@GetMapping("/regisration")
	public String userRegistration(Model model)
	{  
		model.addAttribute("getAllQuestion", securityQuestionService.getAllQuestions());
		return "registration";
	}
	
	@GetMapping("/help")
	public String help()
	{  
		return "help";
	}
	
	@GetMapping("/about")
	public String aboutUs()
	{  
		return "aboutus";
	}
	
 }
