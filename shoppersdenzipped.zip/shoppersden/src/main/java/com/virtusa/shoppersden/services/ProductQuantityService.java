package com.virtusa.shoppersden.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.shoppersden.models.Product;
import com.virtusa.shoppersden.models.ProductQuantity;
import com.virtusa.shoppersden.repository.ProductQuantityRepository;

@Service
public class ProductQuantityService {

	@Autowired
	private ProductQuantityRepository productQtyRepository;
	@Autowired
	private CartService cartService;
	@Autowired
	private ProductService productService;
	
	public List<ProductQuantity> getAllProductQuantities() {
		return productQtyRepository.findAll();
	}

	public ProductQuantity addProductQuantity(long phoneNumber,int productId) {
		ProductQuantity productQty=new ProductQuantity();
		productQty.setCart(cartService.getCartByUserId(phoneNumber));
		Product product=productService.findProductById(productId);
		productQty.setProduct(product);
		productQty.setAmount(product.getPrice());
		return productQtyRepository.save(productQty);
	}

	public ProductQuantity updateProductQuantity(ProductQuantity productQty) {
		return productQtyRepository.save(productQty);
	}

	public void deleteProductQuantity(int productQtyId) {
		productQtyRepository.deleteById(productQtyId);
	}
	
}
