package com.virtusa.shoppersden.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Category")
public class Category {

	@Id
	@GenericGenerator(name="categoryId" , strategy="increment")
	@GeneratedValue(generator="categoryId")
	@Column(name = "Category_Id")
	private int categoryId;
	
	@Column(name = "Category_Name", unique = true, nullable = false,updatable = true, length = 50)
	private String categoryName;
	
	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

}
