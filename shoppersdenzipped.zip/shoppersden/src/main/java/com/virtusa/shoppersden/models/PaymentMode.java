package com.virtusa.shoppersden.models;
 public enum PaymentMode {
    debit {
        @Override
        public String toString() {
            return "Debit Card";
        }
    },
    credit {
        @Override
        public String toString() {
            return "Credit Card";
        }
    }
 }