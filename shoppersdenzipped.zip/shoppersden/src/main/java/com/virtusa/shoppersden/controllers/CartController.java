package com.virtusa.shoppersden.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import com.virtusa.shoppersden.models.Cart;
import com.virtusa.shoppersden.services.CartService;

@RestController
@SessionAttributes("phoneNumber")
public class CartController {

	@Autowired
	private CartService cartService;

	@GetMapping("/getcart")
	public @ResponseBody Cart getAllCarts(@ModelAttribute("phoneNumber") long phoneNumber) {
		return cartService.getCartByUserId(phoneNumber);
	}

	@PostMapping("/addcart")
	public Cart addCart(@RequestBody Cart cart, @ModelAttribute("phoneNumber") long phoneNumber) {
		return cartService.addCart(cart, phoneNumber);
	}
	
	@PostMapping("/deletecart")
	public void deletecart(@RequestBody Cart cart,int cartId) {
		cartService.deleteCart(cartId);
	}

}
