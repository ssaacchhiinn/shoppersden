package com.virtusa.shoppersden.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.virtusa.shoppersden.models.User;
import com.virtusa.shoppersden.services.CategoryService;
import com.virtusa.shoppersden.services.ProductService;
import com.virtusa.shoppersden.services.UserRoleService;
import com.virtusa.shoppersden.services.UserService;

@Controller
@SessionAttributes("phoneNumber")
public class UserController {

	@Autowired 
	private UserService userService;
	@Autowired
	private UserRoleService userRoleService;
	@Autowired
	private CategoryService categoryService; 
	@Autowired
	private ProductService productService; 

	
	@GetMapping("/user")
	public String getAllUsers(Model model,Model roleModel)
	{
		 model.addAttribute("getusers",userService.getAllUsers());
		 roleModel.addAttribute("getuserroles", userRoleService.getAllUserRole());
		 return "admin/user";
	}
	
	@PostMapping("/updateUserRole")
	public String updateUserRole(@ModelAttribute User user)
	{
		userService.updateUserRole(user);
		return "redirect:/user";
	}
	
	@GetMapping("/resetpasswordpage")
	public String resetHome() 
	{
		return "resetpassword";
	}
	
	@PostMapping("/adduser")
	public String addUser(@ModelAttribute User user,@RequestParam int questionId)
	{
			userService.addUser(user,questionId);
			return "login";
	}
	
	@PostMapping("/getSecurityQuestion")
	public String getSecurityQuesion(@ModelAttribute User user,Model model)
	{
		model.addAttribute("userQuestion",userService.getuserSequerityquestion(user));
		return "useranswer";
		   
	} 
	
	@PostMapping("/resetPassword")
	public String resetPassword(@ModelAttribute User user)
	{
		userService.updateUserPassword(user);
		return "login";
	} 
	
	@PostMapping("/updateuser/{questionId}")
	public User updateUser(@RequestBody User user, @PathVariable int questionId)
	{
		return userService.updateUser(user, questionId);
	}
	
	@PostMapping("/authenticateUser")
	public String auhenticateUser(@ModelAttribute User user,Model model)
	{
		if(userService.authenticateUser(user))
		{
			model.addAttribute("allcategory",categoryService.getAllCategories());
			model.addAttribute("getproducts", productService.getAllProducts());
			model.addAttribute("phoneNumber", "1234567");
			return "customer/home";
		}
		else
			return "login";
	} 	
	
	@PostMapping("/matchSequertyAnswer")
	public String matchSequertyAnswer(@ModelAttribute User user,Model model) {
		
		if(userService.sequerityAnswerCheck(user))
		{ 
			model.addAttribute("user",user);
			return "resetpassword";
		}
		else {
			model.addAttribute("userQuestion",userService.getuserSequerityquestion(user));
			model.addAttribute("user",user);
			model.addAttribute("message","Your answer was Wrong");
			return "useranswer";
		} 
	}
	
}
 