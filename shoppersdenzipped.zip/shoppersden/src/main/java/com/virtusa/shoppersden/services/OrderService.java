package com.virtusa.shoppersden.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.shoppersden.models.Order;
import com.virtusa.shoppersden.repository.OrderRepository;

@Service
public class OrderService {

	@Autowired
	private OrderRepository orderRepository;

	public List<Order> getAllOrders() {
		return orderRepository.findAll();
	}

	public Order getOrderByOrderId(int orderId) {
		return orderRepository.findById(orderId).orElse(null);
	}

	public Order addOrder(Order order) {
		return orderRepository.save(order);
	}

	public Order updateOrder(Order order) {
		return orderRepository.save(order);
	}

	public boolean deleteOrder(int orderId) {
		boolean status = false;
		orderRepository.deleteById(orderId);
		status = true;
		return status;
	}
	
}
