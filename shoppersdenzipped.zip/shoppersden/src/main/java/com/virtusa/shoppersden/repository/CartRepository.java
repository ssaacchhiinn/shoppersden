package com.virtusa.shoppersden.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.virtusa.shoppersden.models.Cart;

public interface CartRepository extends JpaRepository<Cart, Integer> {
 
	@Query("SELECT ur FROM Cart ur WHERE ur.user.phoneNumber = :phoneNumber")
	 Cart getCartByUserId(@Param("phoneNumber") long phoneNumber);
	  
} 
