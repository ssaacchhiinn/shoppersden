package com.virtusa.shoppersden.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.shoppersden.models.UserRole;
import com.virtusa.shoppersden.repository.UserRoleRepository;

@Service
public class UserRoleService {

	@Autowired
	private UserRoleRepository userRoleRepository;

	public List<UserRole> getAllUserRole() {
		return userRoleRepository.findAll();
	}

	public UserRole getUserRoleById(int roleId) {
		return userRoleRepository.findById(roleId).orElse(null);
	}

	public UserRole addUserRole(UserRole userRole) {
		return userRoleRepository.save(userRole);
	}

	public boolean deleteUserRole(int roleId) {
		boolean status = false;
		userRoleRepository.deleteById(roleId);
		status = true;
		return status;
	}
	
	public UserRole updateUserRole(UserRole userRole) {
		return userRoleRepository.save(userRole);
	}
	
}
