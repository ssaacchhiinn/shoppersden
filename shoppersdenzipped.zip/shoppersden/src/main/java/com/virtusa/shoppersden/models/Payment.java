package com.virtusa.shoppersden.models;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

@Entity
@Table(name = "Payment")
public class Payment {

	@Id
	@GenericGenerator(name="transactionId" , strategy="increment")
	@GeneratedValue(generator="transactionId")
	@Column(name = "Transaction_Id")
	private long transactionId;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "Order_Id", nullable = false)
	private Order order;
	 
	@Column(name = "Transaction_Mode")
	private PaymentMode transactionMode;
	
	@DateTimeFormat(iso = ISO.DATE)
	@Column(name = "Transaction_Date", columnDefinition = "Date")
	private LocalDate transactionDate;

	
	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}
	
	public PaymentMode getTransactionMode() {
		return transactionMode;
	}

	public void setTransactionMode(PaymentMode transactionMode) {
		this.transactionMode = transactionMode;
	}

	public LocalDate getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}
}