$('.table tbody').on('click', '.btn-warning', function() {
				var currow = $(this).closest('tr');
				var phoneNumber = currow.find('td:eq(2)').text();
				$('#phoneNumber').val(phoneNumber);
				$('#usr').html("(" + currow.find('td:eq(0)').text() + ")");
			});
			$('.table').DataTable({
				lengthMenu : [ 5, 10, 25, 50, 100 ]
			});