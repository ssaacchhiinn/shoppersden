	$('.table').DataTable({
		lengthMenu:[5,10,25,50,100]
	});
	$('.table tbody').on('click','.btn-warning',function(){
		var currow=$(this).closest('tr');
		var productId=$(this).val();
		var productName=currow.find('td:eq(0)').text();
		var productSpecification=currow.find('td:eq(1)').text();
		var productPrice=currow.find('td:eq(2)').text();
		var productStock=currow.find('td:eq(3)').text();
		var productCategoryName=currow.find('td:eq(4)').text();
		var imgURL=currow.find(".btn-danger").val();
		$('input[name="productName"]').val(productName);
		$('textarea[name="specification"]').val(productSpecification);
		$('input[name="price"]').val(productPrice);
		$('input[name="stock"]').val(productStock);
		$('#productId').attr('name', 'productId').val(productId);
	$("select option").filter(function() {
		  return $(this).text() == productCategoryName;
		}).prop('selected', true);
	$('#title-addproduct').html("Update Product");
	$('#addproduct').html("Update");
	});
	$('#openaddproduct').click(function(){
		$('input[name="productName"]').val("");
		$('textarea[name="specification"]').val("");
		$('input[name="price"]').val("");
		$('input[name="stock"]').val("");
		$('input[name="category"]').val("");
		$('#productId').removeAttr("name");
		$('#title-addproduct').html("Add New Product");
		$('#addproduct').html("Add Product");
		//$('input[name="imageURL"]').attr('required','required');
	});