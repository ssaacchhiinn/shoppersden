$('.table tbody').on('click', '.btn-warning', function() {
				var currow = $(this).closest('tr');
				var categoryId = currow.find('td:eq(0)').text();
				var categoryName = currow.find('td:eq(1)').text();
				$('#categoryName').val(categoryName);
				$('#categoryId').attr('name', 'categoryId').val(categoryId);
				$('#category-title').html("Update Category");
				$('#add-category').html("Update");
			});
			$('#openaddcategory').click(function() {
				$('#categoryName').val("");
				$('#categoryId').removeAttr("name");
				$('#category-title').html("Add New Category");
				$('#add-category').html("Add Category");
			});
			$('.table').DataTable({
				lengthMenu : [ 5, 10, 25, 50, 100 ]
			});